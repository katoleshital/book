package com.bookstore.java.dto;

public interface BookResponseProj {

	Integer getBookId();

	String getBookName();

	String getAuthor();

	String getGenre();

	double getPrice();

	Integer getRating();
}
