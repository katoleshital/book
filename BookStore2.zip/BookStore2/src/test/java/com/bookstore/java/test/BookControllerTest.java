package com.bookstore.java.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bookstore.java.controller.BookController;
import com.bookstore.java.dto.BookRequestDto;
import com.bookstore.java.dto.BookResponseDto;
import com.bookstore.java.dto.BookResponseProj;
import com.bookstore.java.repository.BookRepository;
import com.bookstore.java.service.BookService;


@ExtendWith(MockitoExtension.class)
public class BookControllerTest {
	@Mock
	BookService bookService;
	@InjectMocks
	BookController bookController;
	BookRepository bookRepository;
	BookRequestDto bookRequestDto;

	@BeforeEach
	public void setUp() {
		bookRequestDto = new BookRequestDto();
		bookRequestDto.setBookName("corejava");
		bookRequestDto.setAuthor("sdk");
		bookRequestDto.setGenre("tech");
		bookRequestDto.setPrice(345d);
		bookRequestDto.setRating(4);

	}

	@Test
	@DisplayName("user login: positive scenario")
	public void getBookById_Positive() {
		BookResponseDto responseDto = new BookResponseDto();
		when(bookService.getBookByName(responseDto.getBookName())).thenReturn(responseDto);
		
		/*
		 * BookResponseDto result =
		 * bookController.getBookItemByName(responseDto.getBookName());
		 * assertEquals(responseDto, (result).getBody());
		 * assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
		 */
	}

}
